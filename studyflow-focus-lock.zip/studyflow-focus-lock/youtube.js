// Educational-only mode for YouTube (best effort: relies on YouTube's page markup)
let cfg=null;
const load=()=>chrome.storage.local.get({locks:{}}).then(d=>{const l=d.locks['youtube.com'];cfg=l&&l.mode==='edu'&&l.until>Date.now()?l:null});
chrome.storage.onChanged.addListener(load);load();
function verdict(){
  const p=location.pathname;
  if(p==='/'||p.startsWith('/shorts')||p.startsWith('/feed/trending')||p.startsWith('/feed/explore'))return false;
  if(p!=='/watch')return true;
  const vid=new URLSearchParams(location.search).get('v');
  const idMeta=document.querySelector('meta[itemprop="videoId"]');
  const ch=(document.querySelector('ytd-video-owner-renderer #channel-name a, #owner #channel-name a, #upload-info #channel-name a')||{}).textContent;
  if(!idMeta||idMeta.content!==vid||!ch)return null; // still loading
  const name=ch.trim().toLowerCase(),genre=(document.querySelector('meta[itemprop="genre"]')||{}).content;
  return cfg.channels.some(c=>name.includes(c))||(cfg.allowEdu&&genre==='Education');
}
function overlay(text){
  let o=document.getElementById('sf-lock');
  if(!o){o=document.createElement('div');o.id='sf-lock';
    o.style.cssText='position:fixed;inset:0;z-index:2147483647;background:#0b1220;color:#e2e8f0;display:grid;place-items:center;text-align:center;font:16px/1.6 system-ui,sans-serif;padding:24px';
    o.innerHTML='<div style="max-width:440px"><div style="font-size:24px;font-weight:700;color:#fff;margin-bottom:8px">Educational mode is on</div><div id="sf-msg" style="color:#94a3b8"></div><a href="/results?search_query=lecture" style="display:inline-block;margin-top:18px;background:#4338ca;color:#fff;padding:10px 18px;border-radius:9px;text-decoration:none;font-weight:600">Search for a lesson</a></div>';
    document.documentElement.append(o)}
  o.querySelector('#sf-msg').textContent=text;
}
setInterval(()=>{
  const o=document.getElementById('sf-lock');
  if(!cfg||cfg.until<=Date.now()){o&&o.remove();return}
  const v=verdict();
  if(v===true){o&&o.remove();return}
  overlay(v===null?'Checking this video…':'This page isn’t on your approved educational list. It unlocks at '+new Date(cfg.until).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})+'.');
  document.querySelectorAll('video').forEach(x=>x.pause());
},700);
