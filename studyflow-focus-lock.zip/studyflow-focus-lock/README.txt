StudyFlow Focus Lock — browser extension (Chrome, Edge, Brave, Opera, Arc)
=========================================================================
It blocks the websites you pick on the StudyFlow Focus Lock page, for the time you pick.
A lock can be extended but never shortened or switched off early.

INSTALL (about 1 minute)
1. Unzip this folder somewhere you will keep it (for example Documents).
2. Open chrome://extensions  (Edge: edge://extensions, Brave: brave://extensions).
3. Turn on "Developer mode" (top-right).
4. Click "Load unpacked" and choose the studyflow-focus-lock folder.
5. Open StudyFlow > Focus Lock. It now says "Focus Lock extension connected".

Using StudyFlow as a file on your computer (file:///...)?  Open the extension's
"Details" and turn on "Allow access to file URLs".
Incognito: Details > "Allow in Incognito".

Safari is not supported (Safari needs an App Store extension). Use Chrome, Edge or Brave
for study time, or use Screen Time > App Limits on Mac / iPhone.
