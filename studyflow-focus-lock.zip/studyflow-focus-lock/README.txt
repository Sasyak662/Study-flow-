StudyFlow Focus Lock — browser extension (Chrome, Edge, Brave, Opera, Arc)
=========================================================================
Blocks the apps' websites you pick (YouTube, Instagram, TikTok ...) for the time you pick.
You can cancel a lock any time — unless you started it as a "Strict" lock.

INSTALL (about 1 minute)
1. Unzip this file. Keep the "studyflow-focus-lock" folder (for example in Documents).
2. In Chrome's address bar type:  chrome://extensions   and press Enter.
   (Edge: edge://extensions   Brave: brave://extensions)
3. Turn on "Developer mode" (switch at the top-right).
4. Click "Load unpacked" and choose the studyflow-focus-lock folder.
5. Go back to StudyFlow > Focus Lock and refresh the page. It now says "Blocking is ON".

Safari is not supported. On Mac / iPhone you can use Settings > Screen Time > App Limits.
Android phones: use the StudyFlow Android app to block real apps.
