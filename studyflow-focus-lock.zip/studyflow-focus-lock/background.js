const get=()=>chrome.storage.local.get({locks:{},pomo:null});
const notify=(t,m)=>chrome.notifications.create({type:'basic',iconUrl:'icon.png',title:t,message:m});
async function sync(){
  const d=await get(),now=Date.now();
  for(const k of Object.keys(d.locks)) if(d.locks[k].until<=now) delete d.locks[k];
  await chrome.storage.local.set({locks:d.locks});
  const old=await chrome.declarativeNetRequest.getDynamicRules();
  const add=Object.entries(d.locks).filter(([k,l])=>l.mode==='full').map(([k,l],i)=>({id:i+1,priority:1,
    action:{type:'redirect',redirect:{extensionPath:'/blocked.html?site='+encodeURIComponent(k)+'&until='+l.until}},
    condition:{urlFilter:'||'+k+'^',resourceTypes:['main_frame']}}));
  await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:old.map(r=>r.id),addRules:add});
  const next=Math.min(...Object.values(d.locks).map(l=>l.until));
  await chrome.alarms.clear('expire'); if(isFinite(next)) chrome.alarms.create('expire',{when:next+500});
}
async function schedulePhase(){
  const {pomo}=await get(); await chrome.alarms.clear('phase');
  if(pomo) chrome.alarms.create('phase',{when:Math.max(pomo.end,Date.now()+1000)+300});
}
async function nextPhase(){
  const {pomo}=await get(); if(!pomo) return; const now=Date.now();
  if(now>=pomo.stopAt){await chrome.storage.local.set({pomo:null});notify('Session complete','Your locks have ended. Great work!');return}
  pomo.phase=pomo.phase==='focus'?'break':'focus';
  pomo.end=Math.min(now+(pomo.phase==='focus'?pomo.focus:pomo.brk)*60000,pomo.stopAt);
  await chrome.storage.local.set({pomo});await schedulePhase();
  notify(pomo.phase==='focus'?'Focus time':'Break time',pomo.phase==='focus'?'Back to work. Distractions stay locked.':'Stretch and rest. Locks stay on.');
}
async function start(m){
  m.minutes=Math.min(Math.max(1,Math.round(+m.minutes)||1),720);
  m.sites=(m.sites||[]).filter(s=>/^[a-z0-9.-]+\.[a-z]{2,}$/.test(s.domain));
  m.channels=(m.channels||[]).map(c=>String(c).toLowerCase()).slice(0,30);
  if(!m.sites.length)return;
  const d=await get(),now=Date.now(),until=now+m.minutes*60000;
  for(const s of m.sites){
    const cur=d.locks[s.domain];
    // an active lock can be extended but never weakened or shortened
    d.locks[s.domain]=cur&&cur.until>now?{...cur,until:Math.max(cur.until,until)}
      :{until,mode:s.mode,channels:s.mode==='edu'?m.channels:[],allowEdu:s.mode==='edu'?m.allowEdu:false};
  }
  const stopAt=Math.max(...Object.values(d.locks).map(l=>l.until));
  if(m.pomo&&!(d.pomo&&d.pomo.stopAt>now)) d.pomo={phase:'focus',focus:m.pomo.focus,brk:m.pomo.brk,end:Math.min(now+m.pomo.focus*60000,stopAt),stopAt};
  else if(d.pomo) d.pomo.stopAt=stopAt;
  await chrome.storage.local.set({locks:d.locks,pomo:d.pomo||null});
  await sync();await schedulePhase();
}
chrome.runtime.onMessage.addListener((m,_s,res)=>{
  if(m.type==='status'){get().then(d=>{const now=Date.now();for(const k in d.locks)if(d.locks[k].until<=now)delete d.locks[k];
    res({locks:d.locks,pomo:d.pomo&&d.pomo.stopAt>now?d.pomo:null})});return true}
  (m.type==='start'?start(m):sync()).then(()=>res({ok:true}));return true;
});
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='expire')sync();if(a.name==='phase')nextPhase()});
chrome.runtime.onInstalled.addListener(()=>{sync();schedulePhase()});
chrome.runtime.onStartup.addListener(()=>{sync();schedulePhase()});
