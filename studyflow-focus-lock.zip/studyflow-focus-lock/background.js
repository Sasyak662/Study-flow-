// StudyStarx Focus Lock v1.2 — block apps/sites by NAME (e.g. "youtube"), for a set time.
// A lock can be cancelled any time, unless it was started as a "strict" lock.
const get=()=>chrome.storage.local.get({locks:{},pomo:null});
const notify=(t,m)=>{try{chrome.notifications.create({type:'basic',iconUrl:'icon.png',title:t,message:m})}catch(e){}};
const clean=w=>String(w||'').trim().toLowerCase().replace(/^https?:\/\//,'').replace(/^www\./,'').split('/')[0].replace(/[^a-z0-9.-]/g,'');
// "youtube" -> matches youtube.com, m.youtube.com, youtube.co.uk ... ; "youtu.be" -> that exact site
const filterFor=w=>w.includes('.')?'||'+w+'^':'||'+w+'.';
async function sync(){
  const d=await get(),now=Date.now();
  for(const k of Object.keys(d.locks)) if(d.locks[k].until<=now) delete d.locks[k];
  await chrome.storage.local.set({locks:d.locks});
  const old=await chrome.declarativeNetRequest.getDynamicRules();
  const add=[];let id=1;
  for(const [k,l] of Object.entries(d.locks)){
    if(l.mode!=='full')continue;
    const words=(l.words&&l.words.length?l.words:[k]).map(clean).filter(Boolean);
    for(const w of words) add.push({id:id++,priority:1,
      action:{type:'redirect',redirect:{extensionPath:'/blocked.html?site='+encodeURIComponent(l.label||k)+'&key='+encodeURIComponent(k)+'&until='+l.until+'&strict='+(l.strict?1:0)}},
      condition:{urlFilter:filterFor(w),resourceTypes:['main_frame']}});
  }
  await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:old.map(r=>r.id),addRules:add});
  const next=Math.min(...Object.values(d.locks).map(l=>l.until));
  await chrome.alarms.clear('expire'); if(isFinite(next)) chrome.alarms.create('expire',{when:next+500});
  if(!Object.keys(d.locks).length&&d.pomo){await chrome.storage.local.set({pomo:null});await chrome.alarms.clear('phase')}
}
async function schedulePhase(){
  const {pomo}=await get(); await chrome.alarms.clear('phase');
  if(pomo) chrome.alarms.create('phase',{when:Math.max(pomo.end,Date.now()+1000)+300});
}
async function nextPhase(){
  const {pomo}=await get(); if(!pomo) return; const now=Date.now();
  if(now>=pomo.stopAt){await chrome.storage.local.set({pomo:null});notify('Session complete','Your locks have ended. Great work!');return}
  pomo.phase=pomo.phase==='focus'?'break':'focus';
  pomo.end=Math.min(now+(pomo.phase==='focus'?pomo.focus:pomo.brk)*60000,pomo.stopAt);
  await chrome.storage.local.set({pomo});await schedulePhase();
  notify(pomo.phase==='focus'?'Focus time':'Break time',pomo.phase==='focus'?'Back to work. Distractions stay locked.':'Stretch and rest. Locks stay on.');
}
async function start(m){
  m.minutes=Math.min(Math.max(1,Math.round(+m.minutes)||1),720);
  const sites=(m.sites||[]).map(s=>{const key=clean(s.key||s.name||s.domain);const words=(s.words||[s.domain||key]).map(clean).filter(Boolean);return key&&words.length?{key,words,label:String(s.label||key).slice(0,40),mode:s.mode==='edu'?'edu':'full'}:null}).filter(Boolean);
  const channels=(m.channels||[]).map(c=>String(c).toLowerCase()).slice(0,30);
  if(!sites.length)return;
  const d=await get(),now=Date.now(),until=now+m.minutes*60000,strict=!!m.strict;
  for(const s of sites){
    const cur=d.locks[s.key];
    d.locks[s.key]=cur&&cur.until>now?{...cur,until:Math.max(cur.until,until),strict:cur.strict||strict,words:[...new Set([...(cur.words||[]),...s.words])]}
      :{until,mode:s.mode,words:s.words,label:s.label,strict,channels:s.mode==='edu'?channels:[],allowEdu:s.mode==='edu'?!!m.allowEdu:false};
  }
  const stopAt=Math.max(...Object.values(d.locks).map(l=>l.until));
  if(m.pomo&&!(d.pomo&&d.pomo.stopAt>now)) d.pomo={phase:'focus',focus:m.pomo.focus,brk:m.pomo.brk,end:Math.min(now+m.pomo.focus*60000,stopAt),stopAt};
  else if(d.pomo) d.pomo.stopAt=stopAt;
  await chrome.storage.local.set({locks:d.locks,pomo:d.pomo||null});
  await sync();await schedulePhase();
}
async function cancel(key){
  const d=await get();const keys=key?[key]:Object.keys(d.locks);let blocked=0;
  for(const k of keys){const l=d.locks[k];if(!l)continue;if(l.strict&&l.until>Date.now()){blocked++;continue}delete d.locks[k]}
  const left=Object.values(d.locks);
  if(d.pomo){if(!left.length)d.pomo=null;else d.pomo.stopAt=Math.max(...left.map(l=>l.until))}
  await chrome.storage.local.set({locks:d.locks,pomo:d.pomo});await sync();await schedulePhase();
  return {ok:!blocked,strict:blocked};
}
chrome.runtime.onMessage.addListener((m,_s,res)=>{
  if(m.type==='status'){get().then(d=>{const now=Date.now();for(const k in d.locks)if(d.locks[k].until<=now)delete d.locks[k];
    res({v:'1.2',locks:d.locks,pomo:d.pomo&&d.pomo.stopAt>now?d.pomo:null})});return true}
  if(m.type==='cancel'){cancel(m.key).then(res);return true}
  (m.type==='start'?start(m):sync()).then(()=>res({ok:true}));return true;
});
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='expire')sync();if(a.name==='phase')nextPhase()});
chrome.runtime.onInstalled.addListener(()=>{sync();schedulePhase()});
chrome.runtime.onStartup.addListener(()=>{sync();schedulePhase()});
