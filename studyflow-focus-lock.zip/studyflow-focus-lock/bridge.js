// Lets your StudyStarx website talk to this extension (only on the sites listed in manifest.json).
window.addEventListener('message',async e=>{
  if(e.source!==window||!e.data||e.data.sfTo!=='ext')return;
  let res=null;try{res=await chrome.runtime.sendMessage(e.data.msg)}catch(_){}
  window.postMessage({sfFrom:'ext',id:e.data.id,res},'*');
});
window.postMessage({sfFrom:'ext',hello:true},'*');
