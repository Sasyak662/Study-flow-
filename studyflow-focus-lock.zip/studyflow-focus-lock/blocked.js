const q=new URLSearchParams(location.search),site=q.get('site')||'This site',until=+q.get('until');
document.getElementById('h').textContent=site+' is locked';
document.getElementById('p').textContent='Locked until '+new Date(until).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});
function tick(){const s=Math.max(0,Math.ceil((until-Date.now())/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;
  document.getElementById('t').textContent=(h?h+':'+String(m).padStart(2,'0'):m)+':'+String(x).padStart(2,'0');
  if(!s){document.getElementById('h').textContent='Lock finished';const a=document.getElementById('a');a.hidden=false;a.href='https://'+site;}}
tick();setInterval(tick,1000);
