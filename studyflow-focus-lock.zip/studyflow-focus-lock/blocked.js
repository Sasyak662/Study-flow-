const q=new URLSearchParams(location.search),site=q.get('site')||'This site',until=+q.get('until');
document.getElementById('h').textContent=site+' is locked';
document.getElementById('p').textContent='Locked until '+new Date(until).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});
function tick(){const s=Math.max(0,Math.ceil((until-Date.now())/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;
  document.getElementById('t').textContent=(h?h+':'+String(m).padStart(2,'0'):m)+':'+String(x).padStart(2,'0');
  if(!s){document.getElementById('h').textContent='Lock finished';const a=document.getElementById('a');a.hidden=false;a.href='https://'+(q.get('key')||site).toLowerCase()+((q.get('key')||site).includes('.')?'':'.com');}}
tick();setInterval(tick,1000);
if(q.get('strict')!=='1'){const c=document.getElementById('c');c.hidden=false;c.onclick=()=>{c.textContent='Cancelling…';chrome.runtime.sendMessage({type:'cancel',key:q.get('key')||site.toLowerCase()},r=>{if(r&&r.ok)location.href='https://'+(q.get('key')||site).toLowerCase()+((q.get('key')||site).includes('.')?'':'.com');else c.textContent='This lock can’t be cancelled'})}}
