const $=s=>document.querySelector(s);
const PRESETS=['instagram.com','youtube.com','facebook.com','x.com','tiktok.com','reddit.com','netflix.com','snapchat.com'];
const sel=new Set();
function chips(){const box=$('#chips');box.innerHTML='';
  [...new Set([...PRESETS,...sel])].forEach(d=>{const b=document.createElement('button');b.type='button';b.textContent=d;b.className='chip'+(sel.has(d)?' on':'');
    b.onclick=()=>{sel.has(d)?sel.delete(d):sel.add(d);chips()};box.append(b)});
  $('#yt').hidden=!sel.has('youtube.com');}
const clean=v=>v.trim().toLowerCase().replace(/^https?:\/\//,'').replace(/^www\./,'').split('/')[0];
$('#add').onclick=()=>{const d=clean($('#custom').value);if(d.includes('.')){sel.add(d);$('#custom').value='';chips()}};
const fmt=ms=>{const s=Math.max(0,Math.ceil(ms/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;
  return h?`${h}h ${m}m`:`${m}:${String(x).padStart(2,'0')}`};
async function render(){
  const {locks,pomo}=await chrome.storage.local.get({locks:{},pomo:null}),now=Date.now();
  const act=Object.entries(locks).filter(([k,l])=>l.until>now);
  $('#active').hidden=!act.length;
  $('#locks').innerHTML=act.map(([k,l])=>`<div class="lock"><span>${k}${l.mode==='edu'?' <small>(educational only)</small>':''}</span><span class="t">${fmt(l.until-now)}</span></div>`).join('');
  const p=pomo&&pomo.stopAt>now?pomo:null;$('#pomoBox').hidden=!p;
  if(p){$('#pPhase').textContent=p.phase==='focus'?'FOCUS':'BREAK';$('#pTime').textContent=fmt(p.end-now)}
}
$('#start').onclick=async()=>{
  const msg=t=>$('#msg').textContent=t;
  const mins=Math.round(+$('#dur').value*($('#unit').value==='h'?60:1));
  if(!sel.size)return msg('Pick at least one site to restrict.');
  if(!(mins>=1))return msg('Enter a time of at least 1 minute.');
  const at=new Date(Date.now()+mins*60000).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});
  if(!confirm(`Lock ${[...sel].join(', ')} until ${at}?\nYou will not be able to unlock early.`))return;
  const edu=document.querySelector('input[name=ym]:checked').value==='edu';
  await chrome.runtime.sendMessage({type:'start',minutes:mins,allowEdu:$('#edu').checked,
    channels:$('#chan').value.split(',').map(x=>x.trim().toLowerCase()).filter(Boolean),
    sites:[...sel].map(d=>({domain:d,mode:d==='youtube.com'&&edu?'edu':'full'})),
    pomo:$('#pomo').checked?{focus:+$('#pf').value||25,brk:+$('#pb').value||5}:null});
  sel.clear();chips();msg('');render();
};
chrome.runtime.sendMessage({type:'sync'});chips();render();setInterval(render,1000);
