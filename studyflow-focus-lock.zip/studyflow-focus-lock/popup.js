const $=s=>document.querySelector(s);
const APPS=[['youtube','YouTube','▶️',['youtube','youtu.be']],['instagram','Instagram','📸',['instagram']],['tiktok','TikTok','🎵',['tiktok']],['snapchat','Snapchat','👻',['snapchat']],['whatsapp','WhatsApp','💬',['whatsapp']],['netflix','Netflix','🎬',['netflix']],['reddit','Reddit','👽',['reddit']],['x','X','✖️',['x.com','twitter']],['facebook','Facebook','📘',['facebook','fb.com']],['discord','Discord','🎮',['discord']],['twitch','Twitch','📺',['twitch']],['pinterest','Pinterest','📌',['pinterest']]];
const sel=new Set(),extra=[];let mins=60;
function apps(){$('#apps').innerHTML=APPS.concat(extra).map(a=>`<button class="app${sel.has(a[0])?' on':''}" data-k="${a[0]}"><span>${a[2]}</span>${a[1]}</button>`).join('')}
$('#apps').onclick=e=>{const b=e.target.closest('.app');if(!b)return;const k=b.dataset.k;sel.has(k)?sel.delete(k):sel.add(k);apps()};
$('#add').onclick=()=>{const w=$('#custom').value.trim().toLowerCase().replace(/^https?:\/\//,'').replace(/^www\./,'').split('/')[0].replace(/\.(com|net|org|in|co)$/,'').replace(/[^a-z0-9.-]/g,'');if(!w)return;if(!APPS.concat(extra).some(a=>a[0]===w))extra.push([w,w[0].toUpperCase()+w.slice(1),'🚫',[w]]);sel.add(w);$('#custom').value='';apps()};
$('#dur').innerHTML=[[25,'25m'],[45,'45m'],[60,'1h'],[120,'2h'],[180,'3h']].map(d=>`<button data-m="${d[0]}" class="${d[0]===mins?'on':''}">${d[1]}</button>`).join('');
$('#dur').onclick=e=>{const b=e.target.closest('button');if(!b)return;mins=+b.dataset.m;[...$('#dur').children].forEach(x=>x.classList.toggle('on',x===b))};
const fmt=ms=>{const s=Math.max(0,Math.ceil(ms/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return h?`${h}h ${m}m`:`${m}:${String(x).padStart(2,'0')}`};
async function render(){
  const {locks}=await chrome.storage.local.get({locks:{}}),now=Date.now();
  const act=Object.entries(locks).filter(([k,l])=>l.until>now);
  $('#active').hidden=!act.length;
  $('#locks').innerHTML=act.map(([k,l])=>`<div class="lock"><b>${l.label||k}</b><span class="t">${fmt(l.until-now)}</span>${l.strict?'<span class="s">🔒 strict</span>':`<button class="x" data-c="${k}">Cancel</button>`}</div>`).join('');
}
$('#locks').onclick=e=>{const b=e.target.closest('[data-c]');if(!b)return;chrome.runtime.sendMessage({type:'cancel',key:b.dataset.c},render)};
$('#start').onclick=async()=>{
  if(!sel.size){$('#msg').textContent='Pick at least one app or website.';return}
  const all=APPS.concat(extra);
  await chrome.runtime.sendMessage({type:'start',minutes:mins,strict:$('#strict').checked,sites:[...sel].map(k=>{const a=all.find(x=>x[0]===k);return{key:k,label:a[1],words:a[3],mode:'full'}})});
  sel.clear();apps();$('#msg').textContent='';render();
};
chrome.runtime.sendMessage({type:'sync'});apps();render();setInterval(render,1000);
